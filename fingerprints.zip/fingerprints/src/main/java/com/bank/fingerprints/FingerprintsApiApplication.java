package com.bank.fingerprints;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FingerprintsApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FingerprintsApiApplication.class, args);
	}

}
