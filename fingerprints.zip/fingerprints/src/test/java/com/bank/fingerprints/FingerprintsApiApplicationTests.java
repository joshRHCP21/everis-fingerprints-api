package com.bank.fingerprints;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FingerprintsApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
